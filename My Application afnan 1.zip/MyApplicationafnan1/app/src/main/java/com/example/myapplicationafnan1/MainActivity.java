package com.example.myapplicationafnan1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView  calculator = findViewById(R.id.calculator);
        TextView total = findViewById(R.id.total );
        EditText firstNumber = findViewById(R.id.firstNumber);
        EditText secondNumber = findViewById(R.id.secondNumber) ;
        button CALCULATER = findViewById(R.id.CALCULATER ) ;

    }

}