package com.example.myapplicationafnan1;

public class EditText {
}
